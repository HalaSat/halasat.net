<?php

include_once QODE_SHORTCODES_ROOT_DIR.'/comparison-slider/cmp-slider.php';
include_once QODE_SHORTCODES_ROOT_DIR.'/comparison-slider/functions.php';