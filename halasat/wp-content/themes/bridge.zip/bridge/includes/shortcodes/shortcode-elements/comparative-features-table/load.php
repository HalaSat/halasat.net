<?php

require_once QODE_SHORTCODES_ROOT_DIR.'/comparative-features-table/functions.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/comparative-features-table/comparative-features-table.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/comparative-features-table/options-map/map.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/comparative-features-table/custom-styles/custom-styles.php';