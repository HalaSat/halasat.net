<?php

include_once QODE_SHORTCODES_ROOT_DIR.'/info-card/functions.php';
include_once QODE_SHORTCODES_ROOT_DIR.'/info-card/info-card.php';