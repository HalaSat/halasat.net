<?php

require_once QODE_SHORTCODES_ROOT_DIR.'/elliptical-slider/functions.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/elliptical-slider/elliptical-slider.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/elliptical-slider/elliptical-slide.php';