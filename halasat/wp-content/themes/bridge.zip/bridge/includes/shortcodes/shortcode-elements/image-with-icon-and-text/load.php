<?php

include_once QODE_SHORTCODES_ROOT_DIR.'/image-with-icon-and-text/functions.php';
include_once QODE_SHORTCODES_ROOT_DIR.'/image-with-icon-and-text/image-with-icon-and-text.php';