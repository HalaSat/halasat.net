<?php
require_once QODE_SHORTCODES_ROOT_DIR.'/advanced-pricing-list/functions.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/advanced-pricing-list/advanced-pricing-list.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/advanced-pricing-list/options-map/map.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/advanced-pricing-list/custom-styles/custom-styles.php';