<?php
include_once QODE_SHORTCODES_ROOT_DIR . '/advanced-image-gallery/functions.php';
include_once QODE_SHORTCODES_ROOT_DIR . '/advanced-image-gallery/advanced-image-gallery.php';