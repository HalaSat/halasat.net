<?php

require_once QODE_SHORTCODES_ROOT_DIR.'/interest-rate-calculator/functions.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/interest-rate-calculator/interest-rate-calculator.php';