<?php
if(qode_qode_tours_installed() || qode_qode_listing_installed() || qode_qode_lms_installed()) {
	include_once QODE_FRAMEWORK_MODULES_ROOT_DIR . '/reviews/reviews-functions.php';
}